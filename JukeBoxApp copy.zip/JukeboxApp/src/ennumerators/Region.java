package ennumerators;

/**
 * Enumerator that models the different possible regions an interpreter can come from
 * @author Pedro Guillermo Feij�o-Garc�a
 */
public enum Region 
{
	NORTH_AMERICA,
	SOUTH_AMERICA,
	EUROPE,
	AFRICA, 
	ASIA,
	AUSTRALIA
}
