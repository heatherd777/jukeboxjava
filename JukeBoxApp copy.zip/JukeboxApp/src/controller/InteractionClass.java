package controller;

import java.util.Scanner;

import ennumerators.Genre;
import ennumerators.Region;
import model.Album;
import model.Interpreter;
import model.Jukebox;
import model.Song;

/**
 * Class that models the interaction window with the user.
 * @author Pedro Guillermo Feij�o-Garc�a and Heather Davis
 */
public class InteractionClass 
{
	/**
	 * Main method of the application. It controls the execution of the program.
	 * @param args arguments input by the Java Virtual Machine and the environment.
	 */
	public static void main(String[] args) 
	{
		Jukebox model = new Jukebox();
		Scanner input = new Scanner(System.in);
		
		System.out.println("Welcome to JukeboxApp!");
		
		
		boolean continueExecution = true;
		while(continueExecution == true)
		{
			System.out.println("Please select one of the following actions:");
			System.out.println("Add a new album [1]");
			System.out.println("Add a new song to an existing album [2]");
			System.out.println("Add a new hit [3]");
			System.out.println("Search for an existing album [4]");
			System.out.println("Search for a song in an album [5]");
			System.out.println("Search for a hit [6]");
			System.out.println("Delete an album [7]");
			System.out.println("Delete a song from an existing album [8]");
			System.out.println("Delete a hit [9]");
			System.out.println("Retrieve the most expensive album [10]");
			System.out.println("Retrieve the least expensive album [11]");
			System.out.println("Retrieve the longest song in an existing album [12]");
			System.out.println("Retrieve longest hit [13]");
			System.out.println("Retrieve shortest hit [14]");
			System.out.println("Retrieve the number of existing albums [15]");
			System.out.println("Retrieve the number of existing hits [16]");
			
			
			String txtResponse = input.nextLine();
			int response = Integer.parseInt(txtResponse);
			
			//TODO Complete this method for each functional requirement
			
			if(response == 1)
			{
				System.out.println("What is the name of the interpreter?");
				String nameInterpreter = input.nextLine();
				System.out.println("What is the surname of the interpreter?");
				String surnameInterpreter = input.nextLine();
				System.out.println("What is the age of the interpreter?");
				String txtAge = input.nextLine();
				int ageInterpreter = Integer.parseInt(txtAge);
				System.out.println("What is the region of the interpreter?");
				Region regionInterpreter = null;
				System.out.println("Press 1 for Africa");
				System.out.println("Press 2 for Asia.");
				System.out.println("Press 3 for Australia.");
				System.out.println("Press 4 for Europe.");
				System.out.println("Press 5 for North America.");
				System.out.println("Press 6 for South America.");
				
				String inputRegion = input.nextLine();
				int numberRegion = Integer.parseInt(inputRegion);
				Interpreter interpreter = new Interpreter(nameInterpreter, surnameInterpreter, ageInterpreter, regionInterpreter);
				
				if(numberRegion == 1)
				{
					regionInterpreter = Region.AFRICA;
				}
				
				else if(numberRegion == 2)
				{
					regionInterpreter = Region.ASIA;
				}
				
				else if(numberRegion == 3)
				{
					regionInterpreter = Region.AUSTRALIA;
				}
				
				else if(numberRegion == 4)
				{
					regionInterpreter = Region.EUROPE;
				}
				
				else if(numberRegion == 5)
				{
					regionInterpreter = Region.NORTH_AMERICA;
				}
				
				else
				{
					regionInterpreter = Region.SOUTH_AMERICA;
				}
				
				
				System.out.println("Please enter the album's name:");
				String albumName = input.nextLine();
				System.out.println("Please select the album's genre:");
				Genre albumGenre = null;
				System.out.println("Press 1 for Salsa.");
				System.out.println("Press 2 for Gospel.");
				System.out.println("Press 3 for Classical.");
				System.out.println("Press 4 for Hip Hop.");
				System.out.println("Press 5 for RNB.");
				
				String genreSelection = input.nextLine();
				int genreNumber = Integer.parseInt(genreSelection);
				
				if(genreNumber == 1)
				{
					albumGenre = Genre.SALSA;
				}
				
				else if(genreNumber ==2)
				{
					albumGenre = Genre.GOSPEL;
				}
				
				else if(genreNumber == 3)
				{
					albumGenre = Genre.CLASSICAL;
				}
				
				else if(genreNumber == 4)
				{
					albumGenre = Genre.HIPHOP;
				}
				
				else
				{
					albumGenre = Genre.RNB;
				}
				
				System.out.println("Please enter the price of the album:");
				String txtPrice = input.nextLine();
				double priceAlbum = Double.parseDouble(txtPrice);
				
				boolean addedAlbum = model.addAlbum(albumName, albumGenre, priceAlbum, interpreter);
				
				if(addedAlbum == true)
				{
					System.out.println("The album was successfully added.");
				}
				
				else
				{
					System.out.println("The album was not successfully added. Try again.");
				}
				
			}
			
			else if(response == 2)
			{
				//Add a new song to an existing album
				System.out.println("Please input the name of the album.");
				String nameAlbum = input.nextLine();
				
				Album searchedAlbum = model.searchAlbum(nameAlbum);
				
				if(searchedAlbum != null)
				{
					System.out.println("Please input the name of the song.");
					String nameSong = input.nextLine();
					System.out.println("Please put the duration of the song.");
					String txtDuration = input.nextLine();
					int durationSong = Integer.parseInt(txtDuration);
					
					boolean songAdded = model.addSong(nameSong, durationSong, nameAlbum);
					
					if(songAdded == true)
					{
						System.out.println("Your song was succesfully added to the album!");
					}
					
					else
					{
						System.out.println("I am sorry. The song was not added to the album. Please add the album first.");
					}
				}
				
			}
			
			else if(response == 3)
			{
				//Add a new hit to the Jukebox
				System.out.println("Please input the name of the hit song you want to add to Top Hits.");
				String nameHit = input.nextLine();
				
				System.out.println("Please input the name of the album.");
				String nameAlbum = input.nextLine();
			
				boolean addedHit = model.addhit(nameHit, nameAlbum);
				
				if(addedHit == true)
				{
					System.out.println("Your song was succesfully added to the Hits list!");
				}
				
				else
				{
					System.out.println("I am sorry. The song was not added to the Hits list. Try adding the song first.");
				}
				
			}
			
			else if(response == 4)
			{
				//Search for an existing album
				System.out.println("Please input the name of the album.");
				String nameAlbum = input.nextLine();
				
				Album searchedAlbum = model.searchAlbum(nameAlbum);
				
				if(searchedAlbum == null)
				{
					System.out.println("We are sorry, but there is not an album with the name: " + nameAlbum);
				}
				
				else
				{
					System.out.println("The album named " + nameAlbum + " has the following details:");
					System.out.println("\t a. Genre: " + searchedAlbum.getGenre()); 
					System.out.println("\t b. Price: " + searchedAlbum.getPrice());
					System.out.println("\t c. Number of Songs: " + searchedAlbum.getNumberOfExistingSongs());
					System.out.println("\t d. Interpreter: " + searchedAlbum.getInterpreter().getName());
				}
			}
			
			else if(response == 5)
			{
				//Search for a song in an existing album
				System.out.println("Please input the name of the album for the song you would like to find.");
				String nameAlbum = input.nextLine();
			
				Album searchedAlbum = model.searchAlbum(nameAlbum);
				
				if(searchedAlbum != null)
				{
					System.out.println("Please input the name of the song you would like to find.");
					String nameSong = input.nextLine();
					Song searchedSong = searchedAlbum.searchSong(nameSong);
					
					if(searchedSong == null)
					{
						System.out.println("We are sorry, but there is not a song with the name: " + nameSong);
					}
					
					else
					{
						System.out.println("The song named " + nameSong + " has the following details:");
						System.out.println("\t a. Genre: " + searchedAlbum.getGenre()); 
						System.out.println("\t d. Interpreter: " + searchedAlbum.getInterpreter().getName());
					}
				}
				
				else
				{
					System.out.println("We are sorry, but there is not an album with the name: " + nameAlbum + "Please add the album first.");
				}
				
			}
			
			else if(response == 6)
			{
				//Search for a hit in the Jukebox by name
				System.out.println("Please input the name of the hit song you would like to find.");
				String nameHit = input.nextLine();
				
				Song searchedHit = model.searchHit(nameHit);
				
				if(searchedHit == null)
				{
					System.out.println("We are sorry, but there is not a hit with the name: " + nameHit);
				}
				
				else
				{
					System.out.println("The hit song named " + nameHit + " has the following details:");
					System.out.println("\t a. Genre: " + searchedHit.getName()); 
					System.out.println("\t b. Duration: " + searchedHit.getDuration());
				}
			}
			
			else if (response == 7)
			{
				//remove an album from the jukebox, search for its name, boolean
				System.out.println("What is the name of the album you would like to remove?");
				String nameAlbum = input.nextLine();
				
				boolean removedAlbum = model.removeAlbum(nameAlbum);
				 
				if(removedAlbum == false)
				{
					System.out.println("We are sorry, but there is no album with that name in the jukebox.");
				}
				
				else
				{
					System.out.println("The album was succesfully removed from the Jukebox.");
				}
					
			}
			
			else if(response == 8)
			{
				//remove song from album, with name and album, boolean
				System.out.println("What is the name of the song would you like to remove?");
				String removedSong = input.nextLine();
				System.out.println("What is the name of the Album?");
				String songAlbum = input.nextLine();
				
			
				boolean deleted = model.removeSongFromAlbum(removedSong, songAlbum);
				
				if(deleted == false)
				{
					System.out.println("We are sorry, but the song does not exist.");
				}
				
				else
				{
					System.out.println("The song was removed from the album.");
				}	
			}
			
			else if(response == 9)
			{
				//remove a hit by seaching its name
				System.out.println("What is the name of the Hit song you would like to remove?");
				String removedHit = input.nextLine();
				
				boolean removed = model.removeHit(removedHit);
				
				if(removed == false)
				{
					System.out.println("We are sorry, that hit does not exist and was not removed.");
				}
				
				else
				{
					System.out.println("The song was sucessfully removed from the Hit List");
				}
				
				
			}
			
			else if(response == 10)
			{
				//get most expensive album
				Album mostExpensive = model.getMostExpensiveAlbum();
				 
				if(mostExpensive == null)
				{
					System.out.println("This album is not in the Jukebox. =( ");
				}
				
				else
				{
					System.out.println("The most expensive album is named " + mostExpensive.getName() + " and has the following details: ");
					System.out.println("\t a. Genre: " + mostExpensive.getGenre()); 
					System.out.println("\t b. Price: " + mostExpensive.getPrice());
					System.out.println("\t c. Number of Songs: " + mostExpensive.getNumberOfExistingSongs());
					System.out.println("\t d. Interpreter: " + mostExpensive.getInterpreter().getName());
				}
			}
			
			else if(response == 11)
			{
				//get least expensive album
				Album leastExpensive = model.getLeastExpensiveAlbum();
				
				if(leastExpensive == null)
				{
					System.out.println("We are sorry. This album does not exist.");
				}
				
				else
				{
					System.out.println("The least expensive album is named " + leastExpensive.getName() + " and has the following details: ");
					System.out.println("\t a. Genre: " + leastExpensive.getGenre()); 
					System.out.println("\t b. Price: " + leastExpensive.getPrice());
					System.out.println("\t c. Number of Songs: " + leastExpensive.getNumberOfExistingSongs());
					System.out.println("\t d. Interpreter: " + leastExpensive.getInterpreter().getName());
				}
			}
			
			else if(response == 12)
			{
				//get longest song of an album by name
				System.out.println("Please input the name of the album for the longest song you want to find.");
				String nameAlbum = input.nextLine();
				
				Album longestAlbum = model.searchAlbum(nameAlbum);
				
				if(longestAlbum != null)
				{
					
					Song longestSong = model.getLongestSongInAlbum(nameAlbum);
		
					
					if(longestSong == null)
					{
						System.out.println("I'm sorry, the album you input does not have a longest song.");
					}
					
					else
					{
						System.out.println("The longest song on the album is: " + longestSong.getName() + " and is " + longestSong.getDuration() + " minutes long.");
						
					}
				}
				
				else
				{
					System.out.println("Sorry, this album does not exist.");
				}
				
			}
			
			else if(response == 13)
			{
				//get the longest hit
				Song longestHit = model.getLongestHit();
				
				if(longestHit == null)
				{
					System.out.println("Sorry, there are no hits on the Jukebox.");
				}
				
				else
				{
					System.out.println("The longest hit on the Jukebox is " + longestHit.getName() + " and is " + longestHit.getDuration() + " minutes long.");
				}
			}
			
			else if(response == 14)
			{
				//get shortest hit
				Song shortestHit = model.getShortestHit();
				
				if(shortestHit != null)
				{
					System.out.println("The shortest hit on the Jukebox is " + shortestHit.getName() + " and is " + shortestHit.getDuration() + " minutes long.");
				}
				
				else
				{
					System.out.println("Sorry, there are no hits on the Jukebox.");
				}
				
			}
			
			else if(response == 15)
			{
				//get number of existing albums in the jukebox
				int numberAlbums = model.getNumberOfExistingAlbums();
				
				System.out.println("The number of albums in the jukebox is: " + numberAlbums + ".");
			}
			
			else
			{
				//get number of existing hits
				int numberHits = model.getNumberOfExistingHits();
				
				System.out.println("The number of hits in the jukebox is: " + numberHits + ".");
			}
			
				
			System.out.println("Do you want to continue using the app (Y/N)");
			String responseContinue = input.nextLine();
			
			//continueExecution is true
			if(responseContinue.equals("N"))
			{
				continueExecution = false;
			}
		}
		
		input.close();
		
	}
}
