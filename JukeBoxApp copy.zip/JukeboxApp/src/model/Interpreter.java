package model;

import ennumerators.Region;

/**
 * Class that models an interpreter
 * @author Heather Davis and Pedro Guillermo Feij�o-Garc�a
 */
public class Interpreter
{
	
	//--------------------------------------------------------------------------
	// Attributes
	// -------------------------------------------------------------------------
	
	/**
	 * attribute that models the name of the Interpreter
	 */
	private String name;
	
	/**
	 * attribute that models the surname of the Interpreter
	 */
	private String surname;
	
	/**
	 * attribute that models the age of the interpreter
	 */
	private int age;
	
	//--------------------------------------------------------------------------
	// Relations: Enumerators
	// -------------------------------------------------------------------------
	
	/**
	 * an enumeration of regions for the interpreter
	 */
	private Region region;
	

	//--------------------------------------------------------------------------
	// Methods
	// -------------------------------------------------------------------------
	
	/**
	 * a method that creates an object of an instance of the interpreter class <br>
	 * <b> post: </b> an instance of the interpreter class has been created
	 */
	public Interpreter(String pName, String pSurname, int pAge, Region pRegion)
	{
		name = pName;
		surname = pSurname;
		age = pAge;
		region = pRegion;
	}

	
	/**
	 * method that returns the name of the interpreter
	 */
	public String getName() 
	{
		return name;
	}

	/**
	 * method that returns the surname of the interpreter
	 */
	public String getSurname() 
	{
		return surname;
	}

	/**
	 * method that gets and returns the age of the interpreter
	 */
	public int getAge() 
	{
		return age;
	}
	
	/**
	 * method that gets the region of the interpreter
	 */
	public Region getRegion() 
	{
		return region;
	}
	
	
}
