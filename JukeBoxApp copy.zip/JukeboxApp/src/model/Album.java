package model;

import java.util.ArrayList;

import ennumerators.Genre;

/**
 * Class that models an Album
 * @author Pedro Guillermo Feij�o-Garc�a and Heather Davis
 */
public class Album 
{
	//--------------------------------------------------------------------------
	// Constants
	// -------------------------------------------------------------------------
	/**
	 * Constant that models the maximum possible number of songs in an album
	 */
	public static final int NUMBER_SONGS = 12;
	//Pedro says: Just ignore this constant
	
	//--------------------------------------------------------------------------
	// Attributes
	// -------------------------------------------------------------------------
	/**
	 * TODO attribute that models the name of the album
	 */
	private String name;
	
	/**
	 * attribute that models the price of an album
	 */
	private double price;
	
	/**
	 * attribute that models the number of existing songs on an album
	 */
	private int numberOfExistingSongs;
	
	/**
	 * attribute that models the interpreter of an album
	 */
	private Interpreter interpreter;
	
	//--------------------------------------------------------------------------
	// Relations: Enumerators
	// -------------------------------------------------------------------------
	
	/**
	 * attribute that models the enumeration of different genres of the album/s
	 */
	private Genre genre;
	
	//--------------------------------------------------------------------------
	// Relations: Structures
	// -------------------------------------------------------------------------
	
	/**
	 * vector that models the songs in an album
	 */
	private ArrayList<Song> songs;
	
	//--------------------------------------------------------------------------
	// Methods
	// -------------------------------------------------------------------------
	/**
	 * method creates an object of the Album class <br>
	 * <b>post </b> an instance of the album has been created
	 */
	public Album(String pName, Genre pGenre, double pPrice, Interpreter pInterpreter)
	{
		name = pName;
		genre = pGenre;
		price = pPrice;
		interpreter = pInterpreter;
		numberOfExistingSongs = 0;
		songs = new ArrayList<Song>();
	}
	
	/**
	 * method that adds a song to the album <br>
	 * <b>pre: </b> the vector of songs has already been initialized <br>
	 * <b>post: </b> the song has been added to the album <br>
	 * @param pName name of the song
	 * @param pDuration duration of the song
	 * @return true if song was added, otherwise false
	 */
	public boolean addSong(String pName, int pDuration)
	{
		boolean response = false;
		
		Song newSong = searchSong(pName);
		
		if(newSong == null)
		{
			Song addedSong = new Song(pName, pDuration);
			songs.add(addedSong);
			numberOfExistingSongs++;
			response = true;
		}
		return response;
	}
	
	/**
	 * method that searches for a song in the album <br>
	 * <b>pre: </b>  the vector of songs has already been initialized
	 * @param pName name of the song it will look for. pName != null<br>
	 * @return the song if it exists. otherwise null
	 * 
	 */
	public Song searchSong(String pName)
	{
		Song foundSong = null;
		//Do I need to search the album before I search the song? 
		//I had if(pName !=null) but that seems wrong
		for (int i = 0; foundSong == null && i < songs.size(); i++) 
		{
			Song indexSong = songs.get(i);
			if(indexSong.getName().equals(pName))
			{
				foundSong = indexSong;
			}
		}
		return foundSong;
	}
	
	/**
	 * Method that returns the longest song in an album <br>
	 * <b> pre: </b> the vector of songs has already been initialized <br>
	 * @return the longest song in the album otherwise null
	 */
	public Song getLongestSong()
	{
		Song longestSong = null;
		
		for (int i = 0; i < songs.size(); i++)
		{
			Song current = songs.get(i);
			
			if(longestSong == null)
			{
				longestSong = current;
			}
			else if(current.getDuration() > longestSong.getDuration())
			{
				longestSong = current;
			}

		}
		
		return longestSong;
	}
	
	/**
	 * method that removes a song from an album <br>
	 * <b> pre: </b> the vector of songs has already been initialized <br>
	 * <b> post: </b> the song has been removed from the album
	 * @param pName name of the song to be removed pName != null
	 */
	public boolean removeSong(String pName)
	{
		boolean response = false;
		
		if(pName != null)
		{	
			for (int i = 0; i < songs.size() && response == false; i++) 
			{
				Song current = songs.get(i);
				if(current.getName().equals(pName))
				{
					songs.remove(i);
					response = true;
					numberOfExistingSongs--;
				
				}
			}
		}
		
		return response;
	}

	
	/**
	 * method that gets the name of the album and returns the name
	 */
	public String getName() 
	{
		//should I put a null check in here? if(pName != null)?
		return name;
	}

	/**
	 * method that gets the genre of the album and returns the genre
	 */
	public Genre getGenre() 
	{
		return genre;
	}

	/**
	 * method that gets the price and returns the price of the album
	 */
	public double getPrice() 
	{
		return price;
	}

	/**
	 * method that gets the number of existing songs on the album and returns the number of songs
	 */
	public int getNumberOfExistingSongs() 
	{
		return numberOfExistingSongs;
	}

	/**
	 * method that gets the interpreter of the album and returns the interpreter
	 */
	public Interpreter getInterpreter() 
	{
		return interpreter;
	}
	
	
}
