package model;

import java.util.ArrayList;

import ennumerators.Genre;




/**
 * Class that models a Jukebox
 * @author Pedro Guillermo Feij�o-Garc�a and Heather Davis
 */
public class Jukebox 
{
	
	//--------------------------------------------------------------------------
	// Constants
	// -------------------------------------------------------------------------
	
	/**
	 * Constant that models the maximum possible number of top hits
	 */
	public final static int TOP_HITS = 10;
	
	//--------------------------------------------------------------------------
	// Attributes
	// -------------------------------------------------------------------------
	
	/**
	 * Attribute that models the number of existing albums in the jukebox
	 */
	private int numberOfExistingAlbums;
	
	/**
	 * Attribute that models the number of existing hits in the jukebox
	 */
	private int numberOfExistingHits;
	
	//--------------------------------------------------------------------------
	// Relations: Structures
	// -------------------------------------------------------------------------
	
	/**
	 * Vector list that models the dynamic albums in the jukebox
	 */
	private ArrayList<Album> albums;
	
	/**
	 * Array that models the fixed number of hits in the jukebox
	 */
	private Song[] hits;
	
	//--------------------------------------------------------------------------
	// Methods
	// -------------------------------------------------------------------------
	
	/**
     * Method that creates an object (instance) of the Jukebox class<br>
     * <b>post: </b>An instance of type Jukebox has been created<br>
     */
	public Jukebox()
	{
		numberOfExistingAlbums = 0;
		numberOfExistingHits = 0;
		hits = new Song[TOP_HITS];
		albums = new ArrayList<Album>(); 
	}
		
		//TODO Initialize albums
	/*private void initialize()
	{
		for (int i = 0; i < albums.size(); i++)
		{
			albums = null;
		}
	}*/
	
	/**
	 * Method that returns the number of existing albums<br>
	 * @return the number of existing albums
	 */
	public int getNumberOfExistingAlbums()
	{
		//TODO Complete this method
		return numberOfExistingAlbums;
		/*int counting = 0;
		
		int i = 0;
		
		while(i < albums.size()) 
		{
			Album albumX = albums.get(i);
			
			if(albumX != null)
			{
				String xName = albumX.getName();
				
				if(xName.equalsIgnoreCase(pName))
				{
					counting++;
				}
				
			}
			
			i++;
		}
		
		return counting;
	*/
	}
	/**
	 * Method that returns the number of existing hits<br>
	 * @return the number of existing hits
	 */
	public int getNumberOfExistingHits()
	{
		//TODO Complete this method
		return numberOfExistingHits;
		
		/*int counting = 0;
		
		// position 0 to position 9... hits.length = 10
		
		for (int i = 0; i < hits.length; i++) 
		{
			Song iHit = hits[i]; 
			
			if(iHit != null)
			{
				String iName = iHit.getName();
				
				if(iName.equalsIgnoreCase(pName))
				{
					counting++;
				}
			}
		}
		*/
		
	}
	
	/**
	 * Method that adds an album to the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * <b>post: </b>An album has been added to the jukebox.<br>
	 * @param pName name of the new album<br>
	 * @param pGenre genre of the new album<br>
	 * @param pPrice price of the new album. pPrice >= 0.0<br>
	 * @param pInterpreter interpreter of the new album. pInterpreter != null<br>
	 * @return true if the album is created. Otherwise it returns false
	 */
	public boolean addAlbum(String pName, Genre pGenre, double pPrice, Interpreter pInterpreter)
	{
		boolean response = false;
		
		Album existingAlbum = searchAlbum(pName);
		
		if(existingAlbum == null)
		{
			Album addedAlbum = new Album(pName, pGenre, pPrice, pInterpreter);
			albums.add(addedAlbum);
			numberOfExistingAlbums++;
			response = true;
		}
		
		return response;
	}
		/*for (int i = 0; i < albums.size(); i++)
		{
			
			Album addedAlbum = new Album(pName, pGenre, pPrice, pInterpreter);
			return albums.add(addedAlbum);
	        
		}
		
		
		
		return response;
	}/*
	
	/**
	 * Method that searches for an album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * @param pName name of the album it will look for. pName != null<br>
	 * @return the album if it exists. Otherwise null
	 */
	public Album searchAlbum(String pName)
	{
		Album inputAlbum = null;
				
		for(int i = 0; inputAlbum == null && i < albums.size(); i++)
		{
			Album latestAlbum = albums.get(i);
			if(latestAlbum.getName().equals(pName))
			{
				inputAlbum = latestAlbum;
			}
		}
			return inputAlbum;
	}
	
	/**
	 * Method that adds a song to an album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * <b>post: </b>A song has been added to the jukebox.<br>
	 * @param pName name of the song to be added. pName != null<br>
	 * @param pDuration name of the song to be added. pDuration >= 0<br>
	 * @param pNameAlbum name of the album in which the song will be added. pNameAlbum != null<br>
	 * @return true if the song was added. Otherwise false
	 *TODO Complete this method
		/*
		if(searchAlbum(pNameAlbum) != null && albums.searchSong(pName) == null)
		{
			
		}
		*/
		//1) Find out if the album is in the Jukebox
		//Reminder: a (added) is a variable that represents the album we looked for using pNameAlbum
	 //
	 
	public boolean addSong(String pName, int pDuration, String pNameAlbum)
	{
		boolean response = false;
		
		Album searchedAlbum = searchAlbum(pNameAlbum);
		//Song searchedSong = searchedAlbum.searchSong(pName); is this redundant?
		
		if(searchedAlbum != null) //validating if the album is there...or exists
		{
			//When the album exists, we delegate to the album
			//We say> a, please add to yourself the new song
			searchedAlbum.addSong(pName, pDuration);
			response = true;
		}
		
		return response;
	}	
	
	/**
	 * Method that returns the most expensive album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * @return the most expensive album in the jukebox. If there are no albums, it should return null
	 */
	public Album getMostExpensiveAlbum()
	{
		Album mostExpensiveAlbum = null;
		
		//TODO Complete this method
		for(int i = 0; i < albums.size(); i++)
		{
			Album current = albums.get(i);
			if(mostExpensiveAlbum == null)
			{
				mostExpensiveAlbum = current;
			}
			
			else if(mostExpensiveAlbum.getPrice() < current.getPrice())
			{
				mostExpensiveAlbum = current;
			}
			
		}
		
		return mostExpensiveAlbum;
	}
	
	/**
	 * Method that returns the least expensive album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * @return the least expensive album in the jukebox. If there are no albums, it should return null
	 */
	public Album getLeastExpensiveAlbum()
	{
		Album leastExpensiveAlbum = null;
		
		//TODO Complete this method
		for(int i = 0; i < albums.size(); i++)
		{
			Album current = albums.get(i);
			if(leastExpensiveAlbum == null)
			{
				leastExpensiveAlbum = current;
			}
			else if(leastExpensiveAlbum.getPrice() > current.getPrice())
			{
				leastExpensiveAlbum = current;
			}
		}
		
		return leastExpensiveAlbum;
	}
	
	/**
	 * Method that returns the longest song of an existing album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * @param pName name of the album of interest. pName != null <br>
	 * @return the longest song in the album in the jukebox. If there are no albums, it should return null
	 */
	public Song getLongestSongInAlbum(String pName)
	{
		Song longestSong = null;
		
		Album currentAlbum = searchAlbum(pName);
		
		if(currentAlbum != null)
		{
			//TODO Complete this method
			longestSong = currentAlbum.getLongestSong();
			
			
			
		}
		return longestSong;
	}
	
	/**
	 * Method that removes an album from the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * <b>post: </b>An album has been removed from the jukebox.<br>
	 * @param pName name of the album to remove. pName != null<br>
	 * @return true if the album was successfully removed. Otherwise false.
	 */
	public boolean removeAlbum(String pName)
	{
		boolean response = false;
		
		//TODO Complete this method
		Album delete = searchAlbum(pName);
		
		if(delete != null)
		{
			albums.remove(delete);
			response = true;
			numberOfExistingAlbums--;
		}
		
		
		return response;
	}
	
	/**
	 * Method that removes a song from an album in the jukebox<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * <b>post: </b>A song has been removed from the jukebox.<br>
	 * @param pNameSong name of the song to remove. pNameSong != null<br>
	 * @param pNameAlbum name of the album to remove the song from. pNameAlbum != null<br>
	 * @return true if the song was successfully removed. Otherwise false.
	 */
	public boolean removeSongFromAlbum(String pNameSong, String pNameAlbum)
	{
		boolean response = false;
		
		//TODO Complete this method
		Album currentAlbum = searchAlbum(pNameAlbum);
	
		if(currentAlbum != null)
		{
			Song deleted = currentAlbum.searchSong(pNameSong);
			
			if(deleted != null)
			{
				currentAlbum.removeSong(pNameSong);
				response = true;
			}
			
		}
		
		return response;
	}
	
	/**
	 * Method that searches for a hit in the jukebox<br>
	 * <b>pre: </b>The array of hits has already been initialized.<br>
	 * @param pName name of the hit. pName != null <br>
	 * @return the hit (type Song) if it exists. Otherwise it returns null
	 */
	public Song searchHit(String pName)
	{
		Song response = null;
		
		//TODO Complete this method
		for(int i = 0; i < hits.length && response == null; i++)
		{
			if(hits[i] != null)
			{
				if(hits[i].getName().equals(pName))
				{
					response = hits[i];
				}
			}
		}
		
		return response;
	}
	
	/**
	 * Method that adds an existing song to the array of hits in the jukebox<br>
	 * <b>pre: </b>The array of hits has already been initialized.<br>
	 * <b>pre: </b>The vector of albums has already been initialized.<br>
	 * <b>post: </b>A song has been added to the array of hits in the jukebox.<br>
	 * @param pNameSong name of the song that will be added to the hits array. pNameSong != null <br>
	 * @param pNameAlbum name of the album that has the song to be added to the array of hits. pNameAlbum != null <br>
	 * @return true if it was successfully added. Otherwise false
	 */
	public boolean addhit(String pNameSong, String pNameAlbum)
	{
		boolean response = false;
		Album hitAlbum = searchAlbum(pNameAlbum);
		
		if(hitAlbum != null)
		{
			Song hitToAdd = hitAlbum.searchSong(pNameSong);
			
			for(int i=0; i < hits.length && response == false; i++)
			{
				if(hits[i] == null)
				{
					hits[i] = hitToAdd;
					response = true;
				}
			}
			
			numberOfExistingHits++;
			
			
		}
		
		return response;
	}
	
	/**
	 * Method that removes a song from the array of hits in the jukebox<br>
	 * <b>pre: </b>The array of hits has already been initialized.<br>
	 * <b>post: </b>A song has been removed from the array of hits in the jukebox.<br>
	 * @param pName name of the song to be removed. pName != null<br>
	 * @return true if the song was successfully removed from the array of hits. Otherwise false
	 */
	public boolean removeHit(String pName)
	{
		boolean response = false;
		
		//TODO Complete this method
		if(pName != null)
		{
			for(int i = 0; i < hits.length; i++)
		{
				Song hit = hits[i];
				if(hit != null && hit.getName().equals(pName))
				{
					hits[i] = null;
					response = true;
					numberOfExistingHits--;
				}
			}
		}
		
		
		return response;
	}
	
	/**
	 * Method that returns the longest song in the array of hits<br>
	 * <b>pre: </b>The array of hits has already been initialized.<br>
	 * @return the longest song of the array of hits. If there are no songs, returns null.
	 */
	public Song getLongestHit()
	{
		Song longest = null;
		
		for (int i = 0; i < hits.length; i++) 
		{
			Song current = hits[i];
			if(current != null)
			{
				if(longest == null)
				{
					longest = current;
				}
				
				else if(current.getDuration() > longest.getDuration())
				{
					longest = current;
				}
			}
		}
		
		return longest;
	}
	
	/**
	 * Method that returns the shortest song in the array of hits<br>
	 * <b>pre: </b>The array of hits has already been initialized.<br>
	 * @return the shortest song of the array of hits. If there are no songs, returns null.
	 */
	public Song getShortestHit()
	{
		Song shortest = null;
		
		for (int i = 0; i < hits.length; i++)
		{
			Song current = hits[i];
			if(current != null)
			{
				if(shortest == null)
				{
					shortest = current;
				}
				
				else if(current.getDuration() < shortest.getDuration())
				{
					shortest = current;
				}
			}
		}
		
		/*
		 * Small test of arrays
		 
		int[] testList = new int[5];
		*/
		
		return shortest;
	}
	
}
