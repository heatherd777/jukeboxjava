package model;

/**
 * TODO Complete documentation - check Jukebox class
 */
public class Song 
{
	
	//--------------------------------------------------------------------------
	// Attributes
	// -------------------------------------------------------------------------
	
	/**
	 * attribute that models the name of the song
	 */
	private String name;
	
	/**
	 * attribute that models the duration of the song
	 */
	private int duration;
	
	//--------------------------------------------------------------------------
	// Methods
	// -------------------------------------------------------------------------
	
	/**
	 * method that creates an object of the instance of the song class <br>
	 * <b> post: </b> an instance of the song has been created
	 */
	public Song(String pName, int pDuration)
	{
		name = pName;
		duration = pDuration;
		//am I missing something here that causes me to not add songs to the index of the arraylist?
	}

	/**
	 * a method that gets the name of the song and returns the name
	 */
	public String getName() 
	{
		return name;
	}


	/**
	 * a method that gets the duration of a song and returns the integer of duration
	 */
	public int getDuration() 
	{
		return duration;
	}
	
	
	
}
